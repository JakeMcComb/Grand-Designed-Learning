// Grand Designed Learning PWA core
const $ = sel => document.querySelector(sel);
const view = $('#view');
const tabs = document.querySelectorAll('.tab');
const ROUTES = ['home','learn','quizzes','flashcards','profile'];

let deferredPrompt = null;
const installBtn = $('#installBtn');

// Service worker registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(console.error);
  });
}

// Install prompt
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.hidden = false;
});
installBtn?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  console.log('Install prompt outcome:', outcome);
  deferredPrompt = null;
  installBtn.hidden = true;
});

// Router
function routeTo(name) {
  if (!ROUTES.includes(name)) name = 'home';
  window.location.hash = '#' + name;
  render(name);
  tabs.forEach(t => t.classList.toggle('active', t.dataset.view === name));
  view.focus();
}

tabs.forEach(t => t.addEventListener('click', () => routeTo(t.dataset.view)));
window.addEventListener('hashchange', () => render(location.hash.replace('#','') || 'home'));

const state = {
  terms: [],
  quiz: [],
  flashIndex: 0,
  favorites: JSON.parse(localStorage.getItem('gdl_favs')||'[]'),
  plan: localStorage.getItem('gdl_plan') || 'Free',
  points: Number(localStorage.getItem('gdl_points')||0)
};

async function loadData() {
  try {
    const [termsRes, quizRes] = await Promise.all([fetch('data/terms.json'), fetch('data/quiz.json')]);
    state.terms = await termsRes.json();
    state.quiz = await quizRes.json();
  } catch (err) {
    console.error(err);
  }
}

function badge(txt){ return `<span class="badge">${txt}</span>`; }
function planBadge(){ return `<span class="badge plan">${state.plan} Plan</span>`; }

function renderHome() {
  view.innerHTML = `
    <section class="grid">
      <div class="card">
        <h3>Welcome</h3>
        <p>Learn architecture & interior design terms, test yourself with quizzes, and drill flashcards — anywhere, offline.</p>
        <p>${planBadge()} • Points: <strong>${state.points}</strong></p>
      </div>
      <div class="card">
        <h3>Quick Start</h3>
        <ol class="list">
          <li>Tap <strong>Install App</strong> to add GDL to your device.</li>
          <li>Open <strong>Learning</strong> to browse key terms & definitions.</li>
          <li>Try a <strong>10-question quiz</strong> and earn points.</li>
        </ol>
        <button class="btn" onclick="routeTo('quizzes')">Take a quiz</button>
      </div>
    </section>
    <section class="card">
      <h3>Today’s Highlights</h3>
      <ul class="list" id="todayList"></ul>
    </section>
  `;
  // pick 3 random terms
  const ul = $('#todayList');
  const picks = [...state.terms].sort(()=>Math.random()-0.5).slice(0,3);
  ul.innerHTML = picks.map(t => `<li><strong>${t.term}</strong> — ${t.definition} ${badge(t.category)}</li>`).join('');
}

function renderLearn() {
  view.innerHTML = `
    <section class="card">
      <h3>Learning Hub</h3>
      <input class="input" id="search" placeholder="Search architectural terms…" aria-label="Search terms">
      <div id="terms"></div>
    </section>
  `;
  const termsEl = $('#terms');
  const input = $('#search');
  const renderList = (items) => {
    termsEl.innerHTML = items.map(t => `
      <div class="card">
        <h4>${t.term} ${badge(t.category)}</h4>
        <p>${t.definition}</p>
        <details><summary>Why it matters</summary><p>${t.context}</p></details>
        <button class="btn secondary" onclick="toggleFav('${t.term}')">${state.favorites.includes(t.term)?'★ Favorited':'☆ Favorite'}</button>
      </div>
    `).join('');
  };
  renderList(state.terms);
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    renderList(state.terms.filter(t => t.term.toLowerCase().includes(q) || t.definition.toLowerCase().includes(q) || t.category.toLowerCase().includes(q)));
  });
}

function toggleFav(term){
  const i = state.favorites.indexOf(term);
  if (i>=0) state.favorites.splice(i,1); else state.favorites.push(term);
  localStorage.setItem('gdl_favs', JSON.stringify(state.favorites));
  render('learn');
}

function renderQuizzes() {
  view.innerHTML = `
    <section class="card">
      <h3>Architecture Quiz</h3>
      <div id="quizBox"></div>
      <button class="btn" id="startQuiz">Start 10-question quiz</button>
    </section>
  `;
  $('#startQuiz').addEventListener('click', startQuiz);
}

function startQuiz(){
  const q = [...state.quiz].sort(()=>Math.random()-0.5).slice(0,10);
  let idx = 0;
  let score = 0;
  const box = $('#quizBox');
  const renderQ = () => {
    const cur = q[idx];
    const choices = [...cur.choices];
    box.innerHTML = `
      <p><strong>Q${idx+1}:</strong> ${cur.question}</p>
      <div class="grid">
        ${choices.map((c,i)=>`<button class="btn secondary" data-i="${i}">${c}</button>`).join('')}
      </div>
      <p>${badge(cur.category)}</p>
    `;
    box.querySelectorAll('button[data-i]').forEach(btn => btn.addEventListener('click', () => {
      const sel = Number(btn.dataset.i);
      const correct = cur.answer === cur.choices[sel];
      if (correct) { score++; state.points += 10; localStorage.setItem('gdl_points', state.points); }
      idx++;
      if (idx<q.length){ renderQ(); } else {
        box.innerHTML = `<h4>Score: ${score}/${q.length}</h4><p>You earned <strong>${score*10}</strong> points.</p><button class="btn" onclick="routeTo('flashcards')">Review flashcards</button>`;
      }
    }));
  };
  renderQ();
}

function renderFlashcards(){
  view.innerHTML = `
    <section class="card">
      <h3>Flashcards</h3>
      <div id="flash"></div>
      <div style="display:flex; gap:8px; margin-top:8px">
        <button class="btn secondary" id="prev">Prev</button>
        <button class="btn" id="flip">Flip</button>
        <button class="btn secondary" id="next">Next</button>
      </div>
    </section>
  `;
  const items = state.terms;
  if (!items.length){ $('#flash').innerHTML = '<p>Load terms in Learning first.</p>'; return; }
  let i = state.flashIndex % items.length;
  let showDef = false;
  const flash = $('#flash');
  const renderCard = () => {
    const t = items[i];
    flash.innerHTML = `
      <div class="card">
        <h4>${showDef ? t.term : 'What is…?'}</h4>
        <p>${showDef ? t.definition : t.term}</p>
        <p>${badge(t.category)}</p>
      </div>
    `;
  };
  renderCard();
  $('#prev').onclick = ()=>{ i=(i-1+items.length)%items.length; showDef=false; renderCard(); };
  $('#next').onclick = ()=>{ i=(i+1)%items.length; showDef=false; renderCard(); };
  $('#flip').onclick = ()=>{ showDef=!showDef; renderCard(); };
}

function renderProfile(){
  const favs = state.favorites;
  view.innerHTML = `
    <section class="card">
      <h3>Your Profile</h3>
      <p>Plan: ${planBadge()} • Points: <strong>${state.points}</strong></p>
      <h4>Favorites</h4>
      ${favs.length?'<ul class="list">'+favs.map(f=>`<li>${f}</li>`).join('')+'</ul>':'<p>No favorites yet.</p>'}
      <h4>Study Time</h4>
      <p>Set reminders in your calendar to study afternoons. (We’ll add in-app reminders later.)</p>
    </section>
  `;
}

function render(name){
  switch(name){
    case 'home': renderHome(); break;
    case 'learn': renderLearn(); break;
    case 'quizzes': renderQuizzes(); break;
    case 'flashcards': renderFlashcards(); break;
    case 'profile': renderProfile(); break;
    default: renderHome();
  }
}

async function init(){
  document.getElementById('year').textContent = new Date().getFullYear();
  await loadData();
  const route = location.hash.replace('#','') || 'home';
  render(route);
  tabs.forEach(t => t.classList.toggle('active', t.dataset.view === route));
}
init();
